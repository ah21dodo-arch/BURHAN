class DiagnosticResult {
  final String category;
  final String title;
  final String status;
  final String details;
  final DateTime timestamp;

  const DiagnosticResult({
    required this.category,
    required this.title,
    required this.status,
    required this.details,
    required this.timestamp,
  });
}
